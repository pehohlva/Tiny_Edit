#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "startmenubutton.h"
#include <QtCore>
#include <qdebug.h>
#include <QPixmap>
#include <QIcon>
#include <QKeySequence>
#include <QWidgetAction>
#include "startmenubutton.h"




MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap pix(22, 22);
    pix.fill(Qt::red);




      connect(ui->actionopen_book, SIGNAL(triggered()), this, SLOT(showFullScreen()));

    QAction *a;

    menuTocEpub = new QMenu;
    menuTocEpub->setIcon(QIcon(pix));
    ///// limit 30 item qmenu..
    const int porsize = 55;
    for (int x = 0; x < porsize; x++) {
          QString named = QString("Canta in coro %1").arg(x); // cantainQString
          a = new QAction(QIcon(pix),named, this);
          a->setData(QVariant(QString("ilpapadioso_%1").arg(x)));
          connect(a, SIGNAL(triggered()), this, SLOT(showPopupMenu()));
          menuTocEpub->addAction(a);
    }








    _EpubStart = new StartMenuButton();
    _EpubStart->setMenu(menuTocEpub);
    statusBar()->addWidget(_EpubStart);
    statusBar()->setSizeGripEnabled(false);
}



void MainWindow::showPopupMenu()
{
      QString tmp;
      QAction *actionx  = qobject_cast<QAction *>(sender());
        if (actionx) {
             tmp = actionx->data().toString() + actionx->text();
        }

   _EpubStart->pops();
    qDebug()<<"Menu Clicked!" << tmp;
}

MainWindow::~MainWindow()
{
    delete ui;
}
