#ifndef STARTMENUBUTTON_H
#define STARTMENUBUTTON_H

#include <QObject>
#include <QLabel>
#include <QMenu>
#include <QStatusBar>
#include <QMouseEvent>
#include <QApplication>
#include <QDialog>
#include <QBoxLayout>
#include <QToolBar>
#include <QStyle>
#include <QWidgetAction>
#include <QSpinBox>
#include <QCommandLinkButton>

/*     menuTocEpub = new QMenu;
    menuTocEpub->setIcon(QIcon(pix));
    menuTocEpub->addAction(a);
    ///// SpinWidgetAction *ps = new SpinWidgetAction(menuTocEpub);
    menuTocEpub->addAction(ps); */

class SpinWidgetAction : public QWidgetAction
{
public:
 SpinWidgetAction(QObject *parent) : QWidgetAction(parent) {}
 virtual ~SpinWidgetAction() {}
protected:
 virtual QWidget *createWidget(QWidget *parent) {
  QSpinBox *sb = new QSpinBox(parent);
  sb->setToolTip("Spin");
  return sb;
 }
};



/* usage    QAction *a;
      a = new QAction(QIcon(pix), tr("&New Page test"), this);
      a->setShortcut(QKeySequence::New);
      a->setData(QVariant(QString("ilpapadioso")));
      connect(a, SIGNAL(triggered()), this, SLOT(showPopupMenu()));
    menuTocEpub = new QMenu;
    menuTocEpub->setIcon(QIcon(pix));
    menuTocEpub->addAction(a);

*/
class StartMenuButton : public QCommandLinkButton
{
    Q_OBJECT
public:
    StartMenuButton(QWidget *parent = nullptr);
    void setText( const QString txt );
    QMenu* menu();
    QMenu* setMenu(QMenu *pQMenu);
    void pops();
    bool isValidMenu();
protected:
    void mousePressEvent(QMouseEvent *pQEvent);
private:
    QMenu *_pQMenu;
};

#endif // STARTMENUBUTTON_H
