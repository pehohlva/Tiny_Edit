#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "startmenubutton.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void showPopupMenu();


private:
    Ui::MainWindow *ui;
    QMenu *menuTocEpub;
    StartMenuButton *_EpubStart;
};

#endif // MAINWINDOW_H
