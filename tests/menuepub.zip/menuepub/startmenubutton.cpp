#include "startmenubutton.h"

#include <iostream>
#include <vector>
#include <QtCore>
#include <qdebug.h>

#include <QWidgetAction>

StartMenuButton::StartMenuButton(QWidget *parent): QCommandLinkButton(parent), _pQMenu(nullptr)
{
  setText(QString("EBook Toc./Menu"));
  setFixedWidth(160);
  setToolTip(QString("EBook TOC, Table of Contenents."));
  setToolTipDuration(4000);
}

void StartMenuButton::mousePressEvent(QMouseEvent *pQEvent)
{
  if (_pQMenu && pQEvent->button() == Qt::LeftButton) {
    pops();
  }
}

void StartMenuButton::pops()
{
    if (!_pQMenu->isVisible()) {
      _pQMenu->show(); // a trick to force computation of height() before
       QPoint fposinternal(-20, _pQMenu->height() + 20);
      _pQMenu->move(mapToGlobal(pos()) - fposinternal);
    } else _pQMenu->hide();
}

QMenu* StartMenuButton::setMenu(QMenu *pQMenu)
{
    std::swap(_pQMenu, pQMenu);
    return pQMenu;
}

QMenu* StartMenuButton::menu()
{
    return _pQMenu;
}

void StartMenuButton::setText( const QString txt ) {
    //// format here.
    QCommandLinkButton::setText(txt);
}

bool StartMenuButton::isValidMenu() {
    if (_pQMenu) {
        return true;
    } else {
        return false;
    }
}
